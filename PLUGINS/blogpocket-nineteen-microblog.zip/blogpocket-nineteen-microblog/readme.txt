=== Blogpocket Nineteen Microblog Guide ===
Contributors: A. Cambronero
Tags: microblog, gutenberg, genesis, hooks, genesiswp, studiopress, filters, markup, guide
Requires at least: 5.3
Tested up to: 5.3.2
License: GPLv2 or later

Add the micro-posts section, using custom post type, to the WordPress desktop in order to have the possibility of creating a micro-blog.

== Description ==

Once installed, this plugin adds a new option to the left side menu of the WordPress dashboard (micro-posts). Click on "add new" to edit and publish a new micro-post. Manage the micro-posts as if they were posts or pages, assign the "type" taxonomy and thus have a micro-blog apart from your blog.

More info at [Lanza tu blog](https://lanzatu.blog).

**No Genesis Theme Framework required.**

== Installation ==

1. Upload the entire `blogpocket-nineteen-microblog` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==


== Screenshots ==

1. Plugin in action on the webpremium.online demo.

== Changelog ==

= 1.0.0 =
* Initial release