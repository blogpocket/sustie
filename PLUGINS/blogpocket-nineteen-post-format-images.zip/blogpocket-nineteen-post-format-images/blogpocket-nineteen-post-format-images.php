<?php
/*
Plugin Name: Blogpocket Nineteen Post Format Images
Plugin URI: https://lanzatu.blog/plugins/
Description: Add support for aside post format images

Version: 1.0.0
Author: Antonio Cambronero
Author URI: https://www.blogpocket.com
Text Domain: blogpocket-nineteen-post-format-images
License: GPLv2
*/

// ---Start Support aside post format images

add_theme_support( 'genesis-post-format-images' );

// ---End Support aside post format images
