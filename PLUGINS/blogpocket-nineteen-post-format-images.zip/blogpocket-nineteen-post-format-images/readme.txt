=== Blogpocket Nineteen Post Format Images Guide ===
Contributors: A. Cambronero
Tags: post-format, images, gutenberg, genesis, hooks, genesiswp, studiopress, filters, markup, guide
Requires at least: 5.3
Tested up to: 5.3.2
License: GPLv2 or later

Add support for post format images.

== Description ==

Once installed, this plugin adds support for post format images. That means that as long as you have activated support for post formats you will see the icon next to the title of the corresponding entry. This plugin needs style in the css of the active theme and the image files associated with each icon, located within the "images" directory of the active theme. This plugin works well with the Genesis Blogpocket Nineteen Child theme and the Blogpocket Nineteen Microblog plugin.

More info at [Lanza tu blog](https://lanzatu.blog).

**No Genesis Theme Framework required.**

**Support for post format required.**

**Style on CSS recommended**

**Files of the images associated with each icon required in the "images" directory of the active theme.**

**This plugin works good with the Blogpocket Nineteen Microblog plugin and Blogpocket Nineteen Child theme.**

== Installation ==

1. Upload the entire `blogpocket-nineteen-post-format-images` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==


== Screenshots ==

1. Plugin in action on the webpremium.online demo.

== Changelog ==

= 1.0.0 =
* Initial release